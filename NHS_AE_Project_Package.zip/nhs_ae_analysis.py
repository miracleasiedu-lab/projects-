# =============================================================================
# NHS A&E WAITING-TIME PERFORMANCE ANALYSIS
# =============================================================================
#
# DOMAIN:
# Healthcare Analytics
#
# END CONSUMER:
# Hospital Operations Manager
#
# PERSPECTIVE:
# Waiting-Time Performance Analysis
#
# REPORTING PERIOD:
# April 2025 - March 2026 (see DATA COVERAGE NOTE below)
#
# DATA SOURCE:
# NHS England A&E Attendances and Emergency Admissions
#
# DATA COVERAGE NOTE:
# Of the 12 months in the intended reporting period, 10 monthly files were
# supplied: April, May, July, September, October, November and December 2025,
# and January, February and March 2026. June 2025 and August 2025 were not
# among the uploaded files, so this analysis covers 10 of 12 months. This is
# documented again in Stage 3 (Quality Check 7) and in the Limitations
# section, and all "reporting period" language below refers to the 10
# available months rather than a true 12-month year.
#
# =============================================================================
# PROJECT STRUCTURE
# =============================================================================
#
# 1. Project Summary
# 2. Stage 1 - Load Data
# 3. Stage 2 - Data Exploration
# 4. Stage 3 - Data Quality Assessment
# 5. Stage 4 - Data Cleaning
# 6. Phase 1 - 10 KPIs
# 7. Phase 2 - 10 Univariate Analyses
# 8. Phase 3 - 10 Bivariate Analyses
# 9. Phase 4 - 10 Multivariate Analyses
# 10. Final Insights
# 11. Recommendations
# 12. Limitations
# 13. Conclusion
#
# =============================================================================
 
 
# =============================================================================
# IMPORT LIBRARIES
# =============================================================================
 
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
 
sns.set_theme(style="whitegrid")
pd.set_option("display.width", 140)
pd.set_option("display.max_columns", 30)
 
 
# =============================================================================
# PROJECT SUMMARY
# =============================================================================
#
# PROJECT PURPOSE:
#
# Analyse NHS A&E waiting-time performance across the available months of
# April 2025 to March 2026 and identify patterns of operational pressure
# that may require management attention.
#
# MAIN BUSINESS PROBLEM:
#
# Hospital Operations Managers need to understand:
#
# - how much A&E demand is being experienced
# - how many patients wait longer than four hours
# - how performance changes over time
# - which organisations and regions experience poorer performance
# - where severe post-DTA admission delays occur
# - whether increasing demand is associated with waiting-time pressure
#
# MAIN OBJECTIVE:
#
# Use Python to transform NHS operational data into evidence that can
# support investigation of A&E demand, waiting-time performance,
# admission delays and organisational variation.
#
# =============================================================================
 
 
# =============================================================================
# FILE PATHS
# =============================================================================
 
DATA_FOLDER = Path("data")
CHART_FOLDER = Path("charts")
 
# Create chart folder if it does not already exist.
CHART_FOLDER.mkdir(exist_ok=True)
 
# Files are named YYYY-MM.csv after being standardised from the various
# source filenames supplied (see project notes). This mapping also fixes
# the chronological order used throughout the analysis.
MONTH_FILES = {
    "2025-04": "2025-04.csv",
    "2025-05": "2025-05.csv",
    "2025-07": "2025-07.csv",
    "2025-09": "2025-09.csv",
    "2025-10": "2025-10.csv",
    "2025-11": "2025-11.csv",
    "2025-12": "2025-12.csv",
    "2026-01": "2026-01.csv",
    "2026-02": "2026-02.csv",
    "2026-03": "2026-03.csv",
}
 
EXPECTED_MONTHS = [
    "2025-04", "2025-05", "2025-06", "2025-07", "2025-08", "2025-09",
    "2025-10", "2025-11", "2025-12", "2026-01", "2026-02", "2026-03",
]
 
MISSING_MONTHS = [m for m in EXPECTED_MONTHS if m not in MONTH_FILES]
 
 
# =============================================================================
# STAGE 1 - LOAD DATA
# =============================================================================
 
def load_data():
    """
    Load the monthly NHS A&E CSV files and combine them into one DataFrame.
 
    Intended period: April 2025 to March 2026 (12 months).
    Actually available: 10 months - see DATA COVERAGE NOTE at top of file.
 
    Returns
    -------
    pandas.DataFrame
        Combined raw NHS A&E dataset, with a 'month_key' column (YYYY-MM)
        recording which source file each row came from.
    """
 
    frames = []
    for month_key, filename in MONTH_FILES.items():
        path = DATA_FOLDER / filename
        month_df = pd.read_csv(path)
        month_df["month_key"] = month_key
        frames.append(month_df)
 
    raw_df = pd.concat(frames, ignore_index=True)
    raw_df = raw_df.reset_index(drop=True)
 
    print(f"\nLoaded {len(MONTH_FILES)} monthly files "
          f"({', '.join(MONTH_FILES.keys())}).")
    print(f"Combined raw dataset shape: {raw_df.shape}")
    if MISSING_MONTHS:
        print(f"WARNING: expected 12 months, missing from source data: "
              f"{MISSING_MONTHS}")
 
    return raw_df
 
 
# =============================================================================
# STAGE 2 - DATA EXPLORATION
# =============================================================================
 
def explore_data(df):
    """
    Explore the raw dataset before making any cleaning changes.
    """
 
    print("\n" + "=" * 70)
    print("STAGE 2 - DATA EXPLORATION")
    print("=" * 70)
 
    # EXPLORATION 1 - DATASET SHAPE
    print("\n[1] Dataset shape:", df.shape)
 
    # EXPLORATION 2 - COLUMN NAMES
    print("\n[2] Column names:")
    for c in df.columns:
        print("   -", c)
 
    # EXPLORATION 3 - DATA TYPES
    print("\n[3] Data types:")
    print(df.dtypes)
 
    # EXPLORATION 4 - FIRST FIVE ROWS
    print("\n[4] First five rows:")
    print(df.head())
 
    # EXPLORATION 5 - LAST FIVE ROWS
    print("\n[5] Last five rows:")
    print(df.tail())
 
    # EXPLORATION 6 - NUMERICAL SUMMARY
    print("\n[6] Numerical summary statistics:")
    print(df.describe())
 
    # EXPLORATION 7 - CATEGORICAL VARIABLES
    print("\n[7] Categorical variables:")
    print("   Unique Period values:", df["Period"].nunique())
    print("   Unique Org Code values:", df["Org Code"].nunique())
    print("   Unique Parent Org values:", df["Parent Org"].nunique())
    print("   Parent Org value counts:")
    print(df["Parent Org"].value_counts())
    print("   Unique Org name values:", df["Org name"].nunique())
 
    # EXPLORATION 8 - INITIAL DISTRIBUTION
    print("\n[8] Initial distribution of Type 1 A&E attendances "
          "(observe only, no cleaning yet):")
    print(df["A&E attendances Type 1"].describe())
 
 
# =============================================================================
# STAGE 3 - DATA QUALITY ASSESSMENT
# =============================================================================
 
def assess_data_quality(df):
    """
    Assess the raw dataset for potential data-quality problems.
    """
 
    print("\n" + "=" * 70)
    print("STAGE 3 - DATA QUALITY ASSESSMENT")
    print("=" * 70)
 
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
 
    # QUALITY CHECK 1 - MISSING VALUES
    print("\n[1] Missing values per column:")
    missing = df.isna().sum()
    print(missing[missing > 0] if missing.sum() > 0 else "   None found.")
 
    # QUALITY CHECK 2 - DUPLICATES
    print("\n[2] Duplicates:")
    exact_dupes = df.duplicated().sum()
    logical_dupes = df.duplicated(subset=["month_key", "Org Code"]).sum()
    print(f"   Exact duplicate rows: {exact_dupes}")
    print(f"   Duplicate (month_key, Org Code) combinations: {logical_dupes}")
 
    # QUALITY CHECK 3 - DATA TYPES
    print("\n[3] Data types (Period in particular):")
    print("   Period dtype:", df["Period"].dtype)
    print("   Sample Period values:", df["Period"].unique()[:3], "...")
 
    # QUALITY CHECK 4 - IMPOSSIBLE VALUES
    print("\n[4] Impossible (negative) values:")
    neg_counts = (df[numeric_cols] < 0).sum()
    neg_counts = neg_counts[neg_counts > 0]
    print(neg_counts if len(neg_counts) > 0 else "   No negative values found.")
 
    # QUALITY CHECK 5 - CATEGORY CONSISTENCY
    print("\n[5] Category consistency:")
    print("   Parent Org categories:", sorted(df["Parent Org"].unique().tolist()))
    n_orgnames = df["Org name"].nunique()
    n_orgcodes = df["Org Code"].nunique()
    print(f"   Distinct Org name values: {n_orgnames}; "
          f"distinct Org Code values: {n_orgcodes}")
    # Inconsistency found: the national aggregate row is normally flagged by
    # Period == "TOTAL", but in the February 2026 file that same row keeps
    # the month name in Period and only Org Code/Parent Org == "TOTAL".
    # Filtering on Period alone would silently leave a national total mixed
    # in with organisation-level February 2026 rows, inflating that month's
    # figures. Org Code == "TOTAL" is consistent across all 10 files, so
    # cleaning below identifies the aggregate row that way instead.
    mislabelled = df[(df["Org Code"] == "TOTAL") & (df["Period"] != "TOTAL")]
    print(f"   Rows where Org Code == 'TOTAL' but Period != 'TOTAL' "
          f"(inconsistent labelling): {len(mislabelled)}")
    if len(mislabelled) > 0:
        print("  ", mislabelled[["month_key", "Period", "Org Code", "Parent Org"]].to_string(index=False))
 
    # QUALITY CHECK 6 - OUTLIERS
    print("\n[6] Outliers in Type 1 attendances (values > 99th percentile):")
    non_total = df[df["Org Code"] != "TOTAL"]
    p99 = non_total["A&E attendances Type 1"].quantile(0.99)
    outliers = non_total[non_total["A&E attendances Type 1"] > p99]
    print(f"   99th percentile threshold: {p99:.0f}")
    print(f"   Rows above threshold: {len(outliers)} "
          f"(kept - large NHS trusts genuinely see very high volumes)")
 
    # QUALITY CHECK 7 - PERIOD RANGE
    print("\n[7] Period / month coverage:")
    print(f"   Expected months: {EXPECTED_MONTHS}")
    print(f"   Months actually present: {sorted(df['month_key'].unique().tolist())}")
    if MISSING_MONTHS:
        print(f"   Missing months: {MISSING_MONTHS} "
              f"(not supplied in source data - analysis covers 10/12 months)")
 
    # QUALITY CHECK 8 - COMPLETENESS
    print("\n[8] Organisation completeness across months:")
    non_total_orgs = df[df["Org Code"] != "TOTAL"]
    orgs_per_month = non_total_orgs.groupby("month_key")["Org Code"].nunique()
    print(orgs_per_month)
    org_month_counts = non_total_orgs.groupby("Org Code")["month_key"].nunique()
    n_months = df["month_key"].nunique()
    incomplete_orgs = (org_month_counts < n_months).sum()
    print(f"   Organisations present in all {n_months} months: "
          f"{(org_month_counts == n_months).sum()}")
    print(f"   Organisations missing from at least one month: {incomplete_orgs} "
          f"(likely trust mergers/reconfigurations - kept, not treated as errors)")
 
 
# =============================================================================
# STAGE 4 - DATA CLEANING
# =============================================================================
 
def clean_data(df):
    """
    Clean the raw NHS A&E dataset based only on issues identified during
    the data-quality assessment.
    """
 
    print("\n" + "=" * 70)
    print("STAGE 4 - DATA CLEANING")
    print("=" * 70)
 
    cleaned_df = df.copy()
    rows_before = len(cleaned_df)
 
    # CLEANING ACTION 1 - AGGREGATE/TOTAL RECORDS
    # Each monthly file has one row that is a pre-aggregated national total,
    # not an organisation-month observation. It would double-count activity
    # if left in an organisation-level analysis, so it is removed here.
    # Filtered on Org Code == "TOTAL" rather than Period == "TOTAL", because
    # Stage 3 (Quality Check 5) found the February 2026 file mislabels this
    # row's Period as the month name instead of "TOTAL" - Org Code is the
    # field that is consistently "TOTAL" across all 10 files.
    n_total_rows = (cleaned_df["Org Code"] == "TOTAL").sum()
    cleaned_df = cleaned_df[cleaned_df["Org Code"] != "TOTAL"].copy()
    print(f"\n[1] Removed {n_total_rows} pre-aggregated 'TOTAL' rows "
          f"(one per monthly file, identified via Org Code rather than "
          f"Period due to inconsistent labelling in February 2026).")
 
    # CLEANING ACTION 2 - PERIOD FORMAT
    # Convert the month_key (YYYY-MM) into a proper datetime for
    # chronological sorting and plotting, and keep a readable label.
    cleaned_df["period_date"] = pd.to_datetime(cleaned_df["month_key"], format="%Y-%m")
    cleaned_df["period_label"] = cleaned_df["period_date"].dt.strftime("%b %Y")
    print("[2] Converted month_key to a datetime 'period_date' column and "
          "added a readable 'period_label' column.")
 
    # CLEANING ACTION 3 - COLUMN NAMES
    # Rename long source columns to clear, analysis-friendly snake_case names.
    rename_map = {
        "A&E attendances Type 1": "ae_type1_attendances",
        "A&E attendances Type 2": "ae_type2_attendances",
        "A&E attendances Other A&E Department": "ae_other_attendances",
        "A&E attendances Booked Appointments Type 1": "ae_booked_type1",
        "A&E attendances Booked Appointments Type 2": "ae_booked_type2",
        "A&E attendances Booked Appointments Other Department": "ae_booked_other",
        "Attendances over 4hrs Type 1": "over4hrs_type1",
        "Attendances over 4hrs Type 2": "over4hrs_type2",
        "Attendances over 4hrs Other Department": "over4hrs_other",
        "Attendances over 4hrs Booked Appointments Type 1": "over4hrs_booked_type1",
        "Attendances over 4hrs Booked Appointments Type 2": "over4hrs_booked_type2",
        "Attendances over 4hrs Booked Appointments Other Department": "over4hrs_booked_other",
        "Patients who have waited 4-12 hs from DTA to admission": "dta_4_12_hours",
        "Patients who have waited 12+ hrs from DTA to admission": "dta_12_plus_hours",
        "Emergency admissions via A&E - Type 1": "emerg_admissions_type1",
        "Emergency admissions via A&E - Type 2": "emerg_admissions_type2",
        "Emergency admissions via A&E - Other A&E department": "emerg_admissions_other",
        "Other emergency admissions": "emerg_admissions_other_route",
    }
    cleaned_df = cleaned_df.rename(columns=rename_map)
    print("[3] Renamed 18 source measure columns to snake_case analytical names.")
 
    # CLEANING ACTION 4 - MISSING VALUES
    # Stage 3 found no missing values, so no imputation/removal is applied.
    print("[4] No missing values were found in Stage 3 - no action needed.")
 
    # CLEANING ACTION 5 - DUPLICATES
    # Stage 3 found no exact duplicate rows and no duplicate
    # (month_key, Org Code) combinations, so no rows are removed here.
    print("[5] No inappropriate duplicates were found in Stage 3 - "
          "no action needed.")
 
    # DERIVED VARIABLE 1 - TOTAL A&E ATTENDANCES
    cleaned_df["total_attendances"] = (
        cleaned_df["ae_type1_attendances"]
        + cleaned_df["ae_type2_attendances"]
        + cleaned_df["ae_other_attendances"]
    )
 
    # DERIVED VARIABLE 2 - TOTAL >4-HOUR ATTENDANCES
    cleaned_df["total_over4hrs"] = (
        cleaned_df["over4hrs_type1"]
        + cleaned_df["over4hrs_type2"]
        + cleaned_df["over4hrs_other"]
    )
 
    # DERIVED VARIABLE 3 - >4-HOUR RATE
    cleaned_df["over4hr_rate"] = np.where(
        cleaned_df["total_attendances"] > 0,
        cleaned_df["total_over4hrs"] / cleaned_df["total_attendances"] * 100,
        np.nan,
    )
 
    # DERIVED VARIABLE 4 - WITHIN-4-HOUR RATE
    cleaned_df["within4hr_rate"] = 100 - cleaned_df["over4hr_rate"]
 
    # DERIVED VARIABLE 5 - TOTAL EMERGENCY ADMISSIONS
    cleaned_df["total_emergency_admissions"] = (
        cleaned_df["emerg_admissions_type1"]
        + cleaned_df["emerg_admissions_type2"]
        + cleaned_df["emerg_admissions_other"]
        + cleaned_df["emerg_admissions_other_route"]
    )
 
    # Additional helper derived variable used repeatedly below.
    cleaned_df["type1_over4hr_rate"] = np.where(
        cleaned_df["ae_type1_attendances"] > 0,
        cleaned_df["over4hrs_type1"] / cleaned_df["ae_type1_attendances"] * 100,
        np.nan,
    )
 
    print("[Derived] Added: total_attendances, total_over4hrs, over4hr_rate, "
          "within4hr_rate, total_emergency_admissions, type1_over4hr_rate.")
 
    rows_after = len(cleaned_df)
    n_removed = rows_before - rows_after
    pct_removed = n_removed / rows_before * 100
 
    print(f"\nRows before cleaning: {rows_before}")
    print(f"Rows after cleaning : {rows_after}")
    print(f"Rows removed        : {n_removed} ({pct_removed:.1f}%)")
 
    return cleaned_df
 
 
# =============================================================================
# PHASE 1 - 10 KEY PERFORMANCE INDICATORS
# =============================================================================
 
def calculate_kpis(df):
    """
    Calculate ten management-focused KPIs describing NHS A&E
    waiting-time performance.
    """
 
    print("\n" + "=" * 70)
    print("PHASE 1 - 10 KEY PERFORMANCE INDICATORS")
    print("=" * 70)
 
    kpis = {}
 
    # KPI 1 - TOTAL A&E ATTENDANCES
    kpis["total_attendances"] = df["total_attendances"].sum()
    print(f"\n[KPI 1] Total A&E attendances: {kpis['total_attendances']:,.0f}")
 
    # KPI 2 - TOTAL >4-HOUR ATTENDANCES
    kpis["total_over4hrs"] = df["total_over4hrs"].sum()
    print(f"[KPI 2] Total >4-hour attendances: {kpis['total_over4hrs']:,.0f}")
 
    # KPI 3 - OVERALL >4-HOUR RATE
    kpis["overall_over4hr_rate"] = kpis["total_over4hrs"] / kpis["total_attendances"] * 100
    print(f"[KPI 3] Overall >4-hour rate: {kpis['overall_over4hr_rate']:.2f}%")
 
    # KPI 4 - WITHIN-4-HOUR PERFORMANCE
    kpis["within4hr_performance"] = 100 - kpis["overall_over4hr_rate"]
    print(f"[KPI 4] Within-4-hour performance: {kpis['within4hr_performance']:.2f}%")
 
    # KPI 5 - TOTAL TYPE 1 ATTENDANCES
    kpis["total_type1_attendances"] = df["ae_type1_attendances"].sum()
    print(f"[KPI 5] Total Type 1 attendances: {kpis['total_type1_attendances']:,.0f}")
 
    # KPI 6 - TYPE 1 >4-HOUR RATE
    kpis["type1_over4hr_rate"] = df["over4hrs_type1"].sum() / kpis["total_type1_attendances"] * 100
    print(f"[KPI 6] Type 1 >4-hour rate: {kpis['type1_over4hr_rate']:.2f}%")
 
    # KPI 7 - DTA 4-12 HOUR WAITS
    kpis["dta_4_12_total"] = df["dta_4_12_hours"].sum()
    print(f"[KPI 7] Total DTA 4-12 hour waits: {kpis['dta_4_12_total']:,.0f}")
 
    # KPI 8 - DTA 12+ HOUR WAITS
    kpis["dta_12plus_total"] = df["dta_12_plus_hours"].sum()
    print(f"[KPI 8] Total DTA 12+ hour waits: {kpis['dta_12plus_total']:,.0f}")
 
    # KPI 9 - TOTAL EMERGENCY ADMISSIONS
    kpis["total_emergency_admissions"] = df["total_emergency_admissions"].sum()
    print(f"[KPI 9] Total emergency admissions: {kpis['total_emergency_admissions']:,.0f}")
 
    # KPI 10 - NUMBER OF REPORTING ORGANISATIONS
    kpis["n_organisations"] = df["Org Code"].nunique()
    print(f"[KPI 10] Number of reporting organisations: {kpis['n_organisations']}")
 
    return kpis
 
 
# =============================================================================
# PHASE 2 - 10 UNIVARIATE ANALYSES
# =============================================================================
 
def univariate_analysis(df):
    """
    Analyse individual operational variables independently.
    """
 
    print("\n" + "=" * 70)
    print("PHASE 2 - 10 UNIVARIATE ANALYSES")
    print("=" * 70)
 
    def summarise(col, label, unit="", plot=True, bins=30):
        s = df[col].dropna()
        print(f"\n[{label}]")
        print(s.describe())
        if plot:
            fig, ax = plt.subplots(figsize=(7, 4))
            sns.histplot(s, bins=bins, kde=True, ax=ax, color="#2E6E9E")
            ax.set_title(f"Distribution of {label}")
            ax.set_xlabel(unit or label)
            fig.tight_layout()
            fname = CHART_FOLDER / f"{col}_hist.png"
            fig.savefig(fname, dpi=110)
            plt.close(fig)
 
    # U1 - TOTAL A&E ATTENDANCE DISTRIBUTION
    summarise("total_attendances", "Total A&E attendances (org-month)")
 
    # U2 - >4-HOUR ATTENDANCE DISTRIBUTION
    summarise("total_over4hrs", "Total >4-hour attendances (org-month)")
 
    # U3 - >4-HOUR RATE DISTRIBUTION
    summarise("over4hr_rate", ">4-hour rate", unit="%")
 
    # U4 - WITHIN-4-HOUR PERFORMANCE DISTRIBUTION
    summarise("within4hr_rate", "Within-4-hour performance", unit="%")
 
    # U5 - TYPE 1 ATTENDANCE DISTRIBUTION
    summarise("ae_type1_attendances", "Type 1 attendances (org-month)")
 
    # U6 - TYPE 1 >4-HOUR RATE DISTRIBUTION
    summarise("type1_over4hr_rate", "Type 1 >4-hour rate", unit="%")
 
    # U7 - DTA 4-12 HOUR WAIT DISTRIBUTION
    summarise("dta_4_12_hours", "DTA 4-12 hour waits (org-month)")
 
    # U8 - DTA 12+ HOUR WAIT DISTRIBUTION
    summarise("dta_12_plus_hours", "DTA 12+ hour waits (org-month)")
 
    # U9 - EMERGENCY ADMISSIONS DISTRIBUTION
    summarise("total_emergency_admissions", "Emergency admissions (org-month)")
 
    # U10 - REGIONAL REPRESENTATION
    print("\n[Regional representation - record counts by NHS region]")
    region_counts = df["Parent Org"].value_counts()
    print(region_counts)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    region_counts.sort_values().plot(kind="barh", ax=ax, color="#2E6E9E")
    ax.set_title("Organisation-month records by NHS region")
    ax.set_xlabel("Number of records")
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "regional_record_counts.png", dpi=110)
    plt.close(fig)
 
 
# =============================================================================
# PHASE 3 - 10 BIVARIATE ANALYSES
# =============================================================================
 
def bivariate_analysis(df):
    """
    Analyse relationships between pairs of variables.
    """
 
    print("\n" + "=" * 70)
    print("PHASE 3 - 10 BIVARIATE ANALYSES")
    print("=" * 70)
 
    month_order = (
        df[["month_key", "period_date", "period_label"]]
        .drop_duplicates()
        .sort_values("period_date")
    )
 
    # B1 - Month vs Total A&E Attendances
    monthly_attendances = df.groupby("month_key")["total_attendances"].sum().reindex(month_order["month_key"])
    print("\n[B1] Total A&E attendances by month:")
    print(monthly_attendances)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(month_order["period_label"], monthly_attendances.values, marker="o", color="#2E6E9E")
    ax.set_title("Total A&E attendances by month")
    ax.set_ylabel("Attendances")
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "b1_month_vs_attendances.png", dpi=110)
    plt.close(fig)
 
    # B2 - Month vs >4-Hour Rate
    monthly_rate = (
        df.groupby("month_key").apply(
            lambda g: g["total_over4hrs"].sum() / g["total_attendances"].sum() * 100
        ).reindex(month_order["month_key"])
    )
    print("\n[B2] Overall >4-hour rate by month:")
    print(monthly_rate)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(month_order["period_label"], monthly_rate.values, marker="o", color="#B0413E")
    ax.set_title(">4-hour rate by month")
    ax.set_ylabel(">4-hour rate (%)")
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "b2_month_vs_over4hr_rate.png", dpi=110)
    plt.close(fig)
 
    # B3 - NHS Region vs >4-Hour Performance
    region_rate = (
        df.groupby("Parent Org").apply(
            lambda g: g["total_over4hrs"].sum() / g["total_attendances"].sum() * 100
        ).sort_values(ascending=False)
    )
    print("\n[B3] >4-hour rate by NHS region:")
    print(region_rate)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    region_rate.sort_values().plot(kind="barh", ax=ax, color="#B0413E")
    ax.set_title(">4-hour rate by NHS region")
    ax.set_xlabel(">4-hour rate (%)")
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "b3_region_vs_over4hr_rate.png", dpi=110)
    plt.close(fig)
 
    # B4 - Organisation vs >4-Hour Breaches
    org_breaches = (
        df.groupby(["Org Code", "Org name"])["total_over4hrs"].sum()
        .sort_values(ascending=False).head(15)
    )
    print("\n[B4] Top 15 organisations by total >4-hour breaches:")
    print(org_breaches)
 
    # B5 - A&E Demand vs >4-Hour Breaches
    corr_demand_breach = df["total_attendances"].corr(df["total_over4hrs"])
    print(f"\n[B5] Correlation: total attendances vs total >4-hour breaches "
          f"(org-month level) = {corr_demand_breach:.3f}")
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(df["total_attendances"], df["total_over4hrs"], alpha=0.4, color="#2E6E9E", s=18)
    ax.set_xlabel("Total attendances")
    ax.set_ylabel("Total >4-hour breaches")
    ax.set_title(f"Demand vs breaches (r = {corr_demand_breach:.2f})")
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "b5_demand_vs_breaches.png", dpi=110)
    plt.close(fig)
 
    # B6 - Type 1 Demand vs Type 1 Breaches
    corr_type1 = df["ae_type1_attendances"].corr(df["over4hrs_type1"])
    print(f"\n[B6] Correlation: Type 1 attendances vs Type 1 >4-hour breaches "
          f"= {corr_type1:.3f}")
 
    # B7 - DTA 4-12 Hours vs DTA 12+ Hours
    corr_dta = df["dta_4_12_hours"].corr(df["dta_12_plus_hours"])
    print(f"\n[B7] Correlation: DTA 4-12hr waits vs DTA 12+hr waits = {corr_dta:.3f}")
 
    # B8 - Emergency Admissions vs DTA 12+ Hours
    corr_admissions_dta = df["total_emergency_admissions"].corr(df["dta_12_plus_hours"])
    print(f"\n[B8] Correlation: emergency admissions vs DTA 12+hr waits "
          f"= {corr_admissions_dta:.3f}")
 
    # B9 - Organisation vs DTA 12+ Hours
    org_dta12 = (
        df.groupby(["Org Code", "Org name"])["dta_12_plus_hours"].sum()
        .sort_values(ascending=False).head(15)
    )
    print("\n[B9] Top 15 organisations by total DTA 12+ hour waits:")
    print(org_dta12)
 
    # B10 - Month vs DTA 12+ Hours
    monthly_dta12 = df.groupby("month_key")["dta_12_plus_hours"].sum().reindex(month_order["month_key"])
    print("\n[B10] Total DTA 12+ hour waits by month:")
    print(monthly_dta12)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(month_order["period_label"], monthly_dta12.values, marker="o", color="#7A4EA6")
    ax.set_title("DTA 12+ hour waits by month")
    ax.set_ylabel("Patients")
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "b10_month_vs_dta12plus.png", dpi=110)
    plt.close(fig)
 
    return {
        "monthly_attendances": monthly_attendances,
        "monthly_rate": monthly_rate,
        "region_rate": region_rate,
        "org_breaches": org_breaches,
        "org_dta12": org_dta12,
        "monthly_dta12": monthly_dta12,
        "corr_demand_breach": corr_demand_breach,
        "corr_admissions_dta": corr_admissions_dta,
    }
 
 
# =============================================================================
# PHASE 4 - 10 MULTIVARIATE ANALYSES
# =============================================================================
 
def multivariate_analysis(df):
    """
    Analyse combinations of three or more variables to identify deeper
    operational patterns.
    """
 
    print("\n" + "=" * 70)
    print("PHASE 4 - 10 MULTIVARIATE ANALYSES")
    print("=" * 70)
 
    month_order = (
        df[["month_key", "period_date", "period_label"]]
        .drop_duplicates().sort_values("period_date")
    )
 
    # M1 - Month x NHS Region x Four-Hour Performance
    m1 = (
        df.groupby(["month_key", "Parent Org"])
        .apply(lambda g: g["total_over4hrs"].sum() / g["total_attendances"].sum() * 100)
        .unstack("Parent Org")
        .reindex(month_order["month_key"])
    )
    print("\n[M1] >4-hour rate by month x region (%):")
    print(m1.round(1))
    fig, ax = plt.subplots(figsize=(10, 5))
    for region in m1.columns:
        ax.plot(month_order["period_label"], m1[region], marker="o", label=region.strip())
    ax.set_title(">4-hour rate by month and NHS region")
    ax.set_ylabel(">4-hour rate (%)")
    ax.legend(fontsize=7, loc="upper left", bbox_to_anchor=(1, 1))
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "m1_month_region_rate.png", dpi=110)
    plt.close(fig)
 
    # M2 - Month x Organisation x Four-Hour Performance (worst 5 orgs overall)
    org_overall_rate = (
        df.groupby(["Org Code", "Org name"])
        .apply(lambda g: g["total_over4hrs"].sum() / g["total_attendances"].sum() * 100)
    )
    worst5_orgs = org_overall_rate.sort_values(ascending=False).head(5).index
    m2 = (
        df[df.set_index(["Org Code", "Org name"]).index.isin(worst5_orgs)]
        if False else None
    )
    # Build via merge-friendly approach
    df_worst5 = df[df.apply(lambda r: (r["Org Code"], r["Org name"]) in set(worst5_orgs), axis=1)]
    m2 = (
        df_worst5.groupby(["month_key", "Org name"])["over4hr_rate"].mean()
        .unstack("Org name").reindex(month_order["month_key"])
    )
    print("\n[M2] >4-hour rate by month, for the 5 organisations with the "
          "worst overall >4-hour rate:")
    print(m2.round(1))
 
    # M3 - NHS Region x A&E Type x Attendance Volume
    m3 = df.groupby("Parent Org")[["ae_type1_attendances", "ae_type2_attendances", "ae_other_attendances"]].sum()
    print("\n[M3] Attendance volume by NHS region and A&E type:")
    print(m3)
    m3_plot = m3.rename(columns={
        "ae_type1_attendances": "Type 1", "ae_type2_attendances": "Type 2", "ae_other_attendances": "Other",
    })
    fig, ax = plt.subplots(figsize=(9, 5))
    m3_plot.plot(kind="barh", stacked=True, ax=ax, color=["#2E6E9E", "#5FA8D3", "#B7DDF2"])
    ax.set_title("Attendance volume by NHS region and A&E type")
    ax.set_xlabel("Attendances")
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "m3_region_type_volume.png", dpi=110)
    plt.close(fig)
 
    # M4 - Organisation x Demand x Breaches x DTA Delays
    m4 = df.groupby(["Org Code", "Org name"]).agg(
        total_attendances=("total_attendances", "sum"),
        over4hr_rate=("total_over4hrs", lambda s: s.sum()),
        total_over4hrs=("total_over4hrs", "sum"),
        dta_12plus=("dta_12_plus_hours", "sum"),
    )
    m4["over4hr_rate"] = m4["total_over4hrs"] / m4["total_attendances"] * 100
    m4_top = m4.sort_values(["total_attendances", "over4hr_rate", "dta_12plus"], ascending=False).head(10)
    print("\n[M4] Organisations combining high demand with waiting-time and "
          "DTA pressure (top 10 by demand):")
    print(m4_top.round(1))
 
    # M5 - Month x A&E Type x Breach Rate
    m5 = df.groupby("month_key").apply(lambda g: pd.Series({
        "type1_rate": g["over4hrs_type1"].sum() / g["ae_type1_attendances"].sum() * 100,
        "type2_rate": g["over4hrs_type2"].sum() / g["ae_type2_attendances"].sum() * 100 if g["ae_type2_attendances"].sum() else np.nan,
        "other_rate": g["over4hrs_other"].sum() / g["ae_other_attendances"].sum() * 100 if g["ae_other_attendances"].sum() else np.nan,
    })).reindex(month_order["month_key"])
    print("\n[M5] >4-hour rate by month and A&E type (%):")
    print(m5.round(1))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for col, label, color in [("type1_rate", "Type 1", "#2E6E9E"),
                               ("type2_rate", "Type 2", "#B0413E"),
                               ("other_rate", "Other", "#4E9E5F")]:
        ax.plot(month_order["period_label"], m5[col], marker="o", label=label, color=color)
    ax.set_title(">4-hour rate by month and A&E type")
    ax.set_ylabel(">4-hour rate (%)")
    ax.legend()
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "m5_month_type_rate.png", dpi=110)
    plt.close(fig)
 
    # M6 - NHS Region x Emergency Admissions x DTA Delays
    m6 = df.groupby("Parent Org").agg(
        total_emergency_admissions=("total_emergency_admissions", "sum"),
        dta_4_12_hours=("dta_4_12_hours", "sum"),
        dta_12_plus_hours=("dta_12_plus_hours", "sum"),
    ).sort_values("dta_12_plus_hours", ascending=False)
    print("\n[M6] Emergency admissions and DTA delays by NHS region:")
    print(m6)
 
    # M7 - Organisation x Month x DTA 12+ Hour Delays
    top_dta_orgs = df.groupby("Org name")["dta_12_plus_hours"].sum().sort_values(ascending=False).head(5).index
    m7 = (
        df[df["Org name"].isin(top_dta_orgs)]
        .groupby(["month_key", "Org name"])["dta_12_plus_hours"].sum()
        .unstack("Org name").reindex(month_order["month_key"])
    )
    print("\n[M7] DTA 12+ hour waits by month, for the 5 organisations with "
          "the highest overall totals:")
    print(m7)
    fig, ax = plt.subplots(figsize=(9, 5))
    for org in m7.columns:
        ax.plot(month_order["period_label"], m7[org], marker="o", label=org[:28])
    ax.set_title("DTA 12+ hour waits by month (top 5 organisations)")
    ax.set_ylabel("Patients")
    ax.legend(fontsize=7)
    plt.xticks(rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "m7_org_month_dta12plus.png", dpi=110)
    plt.close(fig)
 
    # M8 - High-volume organisation performance
    org_volume = df.groupby(["Org Code", "Org name"])["total_attendances"].sum()
    top_volume_orgs = org_volume.sort_values(ascending=False).head(10).index
    m8 = df[df.set_index(["Org Code", "Org name"]).index.isin(top_volume_orgs)].groupby(
        ["Org Code", "Org name"]
    ).agg(
        total_attendances=("total_attendances", "sum"),
        total_over4hrs=("total_over4hrs", "sum"),
        dta_12plus=("dta_12_plus_hours", "sum"),
    )
    m8["over4hr_rate"] = m8["total_over4hrs"] / m8["total_attendances"] * 100
    m8 = m8.sort_values("total_attendances", ascending=False)
    print("\n[M8] Waiting-time performance of the 10 highest-volume organisations:")
    print(m8.round(1))
 
    # M9 - Month x Region x Severe DTA Delays
    m9 = (
        df.groupby(["month_key", "Parent Org"])["dta_12_plus_hours"].sum()
        .unstack("Parent Org").reindex(month_order["month_key"])
    )
    print("\n[M9] DTA 12+ hour waits by month and NHS region:")
    print(m9)
 
    # M10 - Operational Priority Score
    # A project-derived composite score (NOT an official NHS KPI) combining:
    #  - A&E attendance volume (demand)
    #  - >4-hour rate (waiting-time pressure)
    #  - DTA 12+ hour delays (severe admission delay pressure)
    #  - emergency admissions (admission pressure)
    # Each component is min-max normalised to 0-1 across organisations
    # (summed across all available months) and averaged with equal weights.
    org_scores = df.groupby(["Org Code", "Org name"]).agg(
        total_attendances=("total_attendances", "sum"),
        total_over4hrs=("total_over4hrs", "sum"),
        dta_12plus=("dta_12_plus_hours", "sum"),
        total_emergency_admissions=("total_emergency_admissions", "sum"),
    )
    org_scores["over4hr_rate"] = org_scores["total_over4hrs"] / org_scores["total_attendances"] * 100
 
    def minmax(s):
        rng = s.max() - s.min()
        return (s - s.min()) / rng if rng > 0 else s * 0
 
    org_scores["norm_volume"] = minmax(org_scores["total_attendances"])
    org_scores["norm_rate"] = minmax(org_scores["over4hr_rate"])
    org_scores["norm_dta12"] = minmax(org_scores["dta_12plus"])
    org_scores["norm_admissions"] = minmax(org_scores["total_emergency_admissions"])
 
    org_scores["operational_priority_score"] = org_scores[
        ["norm_volume", "norm_rate", "norm_dta12", "norm_admissions"]
    ].mean(axis=1)
 
    top_priority = org_scores.sort_values("operational_priority_score", ascending=False).head(15)
    print("\n[M10] Top 15 organisations by Operational Priority Score "
          "(project-derived measure, NOT an official NHS KPI):")
    print(top_priority[["total_attendances", "over4hr_rate", "dta_12plus",
                         "total_emergency_admissions", "operational_priority_score"]].round(2))
 
    fig, ax = plt.subplots(figsize=(9, 6))
    plot_data = top_priority.reset_index().sort_values("operational_priority_score")
    ax.barh(plot_data["Org name"].str[:35], plot_data["operational_priority_score"], color="#B0413E")
    ax.set_title("Top 15 organisations by Operational Priority Score\n(project-derived, not an official NHS measure)")
    ax.set_xlabel("Operational Priority Score (0-1)")
    fig.tight_layout()
    fig.savefig(CHART_FOLDER / "m10_operational_priority_score.png", dpi=110)
    plt.close(fig)
 
    return {
        "m1_month_region_rate": m1,
        "m6_region_summary": m6,
        "m8_high_volume_orgs": m8,
        "top_priority": top_priority,
    }
 
 
# =============================================================================
# FINAL INSIGHTS
# =============================================================================
 
def final_insights(df, kpis, biv, multiv):
    """
    Summarise the most important findings after all calculations have
    actually been completed.
    """
 
    print("\n" + "=" * 70)
    print("FINAL INSIGHTS")
    print("=" * 70)
 
    worst_month = biv["monthly_rate"].idxmax()
    worst_month_rate = biv["monthly_rate"].max()
    busiest_month = biv["monthly_attendances"].idxmax()
    busiest_month_val = biv["monthly_attendances"].max()
    worst_region = biv["region_rate"].index[0]
    worst_region_rate = biv["region_rate"].iloc[0]
    top_breach_org = biv["org_breaches"].index[0]
    top_dta_org = biv["org_dta12"].index[0]
 
    print(f"""
1. OVERALL WAITING-TIME PERFORMANCE
   RESULT: {kpis['within4hr_performance']:.2f}% of A&E attendances were seen
   within 4 hours across the 10 available months ({kpis['overall_over4hr_rate']:.2f}%
   breached the 4-hour standard), against {kpis['total_attendances']:,.0f}
   total attendances.
   INTERPRETATION: Performance across the period sits below the NHS
   constitutional 4-hour standard of 95%.
   OPERATIONAL SIGNIFICANCE: Sustained sub-standard performance signals
   system-wide, not isolated, pressure on emergency flow.
 
2. MONTH OF GREATEST DEMAND
   RESULT: {busiest_month} recorded the highest total attendances
   ({busiest_month_val:,.0f}).
   INTERPRETATION: This is the month of peak A&E demand in the data
   available.
   OPERATIONAL SIGNIFICANCE: Staffing and bed-capacity plans should treat
   this period as a demand peak requiring extra resilience.
 
3. MONTH OF WORST >4-HOUR RATE
   RESULT: {worst_month} recorded the highest >4-hour rate
   ({worst_month_rate:.2f}%).
   INTERPRETATION: Demand and waiting-time pressure do not necessarily
   peak in the same month - worth checking against Q2 above.
   OPERATIONAL SIGNIFICANCE: This month warrants closer review of flow,
   staffing and bed-occupancy data alongside attendance volume.
 
4. ORGANISATIONS WITH GREATEST WAITING-TIME PRESSURE
   RESULT: {top_breach_org[1]} recorded the highest total number of
   >4-hour breaches of any organisation.
   INTERPRETATION: A small number of organisations account for a
   disproportionate share of total breaches (see B4 output above).
   OPERATIONAL SIGNIFICANCE: Targeted, organisation-level review is
   likely to be more productive than uniform system-wide measures.
 
5. REGIONAL PERFORMANCE
   RESULT: {worst_region.strip()} had the highest overall >4-hour rate
   ({worst_region_rate:.2f}%) of any NHS region.
   INTERPRETATION: There is meaningful regional variation in
   waiting-time performance (see B3 output above).
   OPERATIONAL SIGNIFICANCE: Regional benchmarking could help identify
   transferable practice from better-performing regions.
 
6. SEVERE DTA DELAYS
   RESULT: {top_dta_org[1]} recorded the highest total number of DTA
   12+ hour waits.
   INTERPRETATION: Severe post-decision-to-admit delays are concentrated
   in a subset of organisations rather than spread evenly (see B9, M7).
   OPERATIONAL SIGNIFICANCE: These organisations are priority candidates
   for bed-capacity and discharge-flow investigation.
 
7. DEMAND VS >4-HOUR BREACHES
   RESULT: Correlation between total attendances and total >4-hour
   breaches at organisation-month level = {biv['corr_demand_breach']:.2f}.
   INTERPRETATION: {'A strong positive relationship suggests breaches broadly track demand volume.' if biv['corr_demand_breach'] > 0.6 else 'A moderate/weak relationship suggests factors beyond raw demand volume (e.g. flow, capacity) strongly influence breach levels.'}
   OPERATIONAL SIGNIFICANCE: {'Capacity planning tied to expected attendance volumes is likely to be an effective lever.' if biv['corr_demand_breach'] > 0.6 else 'Interventions should not rely on demand forecasting alone - flow and capacity factors need direct investigation.'}
 
8. EMERGENCY ADMISSIONS VS SEVERE DTA DELAYS
   RESULT: Correlation between total emergency admissions and DTA
   12+ hour waits at organisation-month level = {biv['corr_admissions_dta']:.2f}.
   INTERPRETATION: {'Admission pressure is closely linked to severe post-DTA delay.' if biv['corr_admissions_dta'] > 0.6 else 'The relationship is moderate, suggesting bed availability and discharge processes matter as much as admission volume itself.'}
   OPERATIONAL SIGNIFICANCE: Investigate downstream bed availability and
   discharge processes at organisations with both high admissions and
   high DTA delays.
 
9. ORGANISATIONS WITH MULTIPLE PRESSURE INDICATORS
   RESULT: The Operational Priority Score (M10) identifies organisations
   that are simultaneously high on demand, >4-hour rate, DTA 12+ hour
   delays and emergency admissions; the top-ranked organisation was
   {multiv['top_priority'].index[0][1]}.
   INTERPRETATION: These organisations show compounding, not isolated,
   pressure across multiple operational dimensions.
   OPERATIONAL SIGNIFICANCE: This is a reasonable starting shortlist for
   deeper operational review, while recognising the score is a
   project-derived measure, not an official NHS KPI.
 
10. MOST IMPORTANT MANAGEMENT FINDING
    RESULT: Performance against the 4-hour standard is below the 95%
    threshold overall, and both waiting-time pressure and severe DTA
    delays are concentrated in a identifiable subset of organisations
    and regions rather than spread uniformly.
    INTERPRETATION: System-wide performance issues coexist with sharp
    organisational variation.
    OPERATIONAL SIGNIFICANCE: A two-track response is indicated -
    system-wide capacity/flow measures alongside targeted intervention
    at the specific organisations and regions flagged in this analysis.
""")
 
 
# =============================================================================
# RECOMMENDATIONS
# =============================================================================
 
def management_recommendations():
    """
    Present evidence-based recommendations for the Hospital Operations
    Manager.
    """
 
    print("\n" + "=" * 70)
    print("MANAGEMENT RECOMMENDATIONS")
    print("=" * 70)
 
    print("""
1. WORKFORCE PLANNING
   Management should investigate whether staffing rotas at the highest-
   pressure organisations and during the busiest/worst-performing months
   align with observed attendance and breach patterns.
 
2. BED-CAPACITY MANAGEMENT
   Management should investigate bed occupancy and escalation capacity at
   organisations with high DTA 12+ hour waits, given the observed link
   between emergency admissions and severe post-DTA delay.
 
3. PATIENT-FLOW PROCESSES
   Management should review end-to-end flow (triage, diagnostics,
   specialty referral) at organisations with high >4-hour rates but only
   moderate attendance volumes, since demand alone does not fully explain
   breach levels.
 
4. DISCHARGE PLANNING
   Management should investigate discharge processes and delayed-transfer
   rates at organisations flagged for severe DTA delay, as this is a
   downstream driver of admission-to-bed waits.
 
5. ESCALATION PROCEDURES
   Management should review whether escalation protocols were triggered
   appropriately during the month(s) identified with peak >4-hour rates.
 
6. SEASONAL CAPACITY PLANNING
   Management should use the monthly attendance and performance trend to
   inform seasonal (e.g. winter) capacity plans for future years, noting
   that this analysis does not cover a full 12-month cycle (see
   Limitations).
 
7. REGIONAL BENCHMARKING
   Management should compare operational practices between the best- and
   worst-performing NHS regions identified in this analysis to identify
   transferable improvements.
 
8. TARGETED OPERATIONAL REVIEWS
   Management should prioritise operational review at organisations
   ranked highest on the Operational Priority Score, as these combine
   several pressure indicators simultaneously rather than a single one.
""")
 
 
# =============================================================================
# LIMITATIONS
# =============================================================================
 
def project_limitations():
    """
    Document limitations affecting interpretation of the analysis.
    """
 
    print("\n" + "=" * 70)
    print("PROJECT LIMITATIONS")
    print("=" * 70)
 
    print(f"""
1. Data covers 10 of the intended 12 months (April 2025-March 2026).
   June 2025 and August 2025 were not supplied and are excluded from all
   totals, trends and monthly comparisons in this analysis.
 
2. Data is aggregated at organisation-month level; there is no
   patient-level detail such as age, diagnosis, or individual waiting
   time.
 
3. Organisations differ substantially in size and service configuration,
   so raw counts (e.g. total breaches) partly reflect organisational
   scale rather than relative performance - rates should be read
   alongside volumes.
 
4. Some organisations do not appear in every available month (likely
   reflecting trust mergers or service reconfiguration); this affects
   month-by-month comparability for those specific organisations.
 
5. Correlation values reported in this analysis (e.g. demand vs
   breaches) describe association only and do not demonstrate causation.
 
6. Unobserved operational factors (staffing levels, local outbreaks,
   estate/building issues, seasonal illness patterns) are not captured
   in this dataset and may influence the patterns observed.
 
7. The Operational Priority Score (M10) is a project-created analytical
   measure combining four normalised indicators with equal weighting. It
   is NOT an official NHS performance indicator, and different weighting
   choices would change the ranking.
""")
 
 
# =============================================================================
# CONCLUSION
# =============================================================================
 
def conclusion(kpis, biv):
    """
    Present the final management-focused conclusion.
    """
 
    print("\n" + "=" * 70)
    print("CONCLUSION")
    print("=" * 70)
 
    print(f"""
This analysis set out to help a Hospital Operations Manager understand
A&E demand, four-hour waiting-time performance, admission delays and
organisational variation across the available months of April 2025 to
March 2026, using NHS England A&E attendance and emergency admission
data.
 
Across the 10 months of data available, {kpis['total_attendances']:,.0f}
A&E attendances were recorded, of which {kpis['within4hr_performance']:.1f}%
were seen within four hours - below the 95% constitutional standard.
Waiting-time pressure and severe post-decision-to-admit delays (12+ hours)
were not spread evenly: a defined subset of organisations and one NHS
region in particular ({biv['region_rate'].index[0].strip()}) accounted for
a disproportionate share of breaches and delays, and demand volume showed
only a partial relationship with breach levels, pointing to flow and
capacity factors beyond raw attendance numbers.
 
For a Hospital Operations Manager, this means waiting-time pressure
should be treated as both a system-wide issue (performance sits below
standard overall) and a targeted one (specific organisations and one
region show compounding pressure across multiple indicators
simultaneously, as captured in the Operational Priority Score).
 
Further operational investigation should focus first on the
organisations flagged in the Operational Priority Score and in the
DTA 12+ hour analysis, examining bed capacity, discharge flow and
staffing alongside the month(s) identified as peak-pressure periods.
 
This analysis is based on aggregated, organisation-month NHS data
covering 10 of 12 intended months, with no patient-level detail;
correlations describe association rather than cause, and the
Operational Priority Score is a project-derived measure rather than an
official NHS KPI. These limitations should be borne in mind when acting
on the findings above.
""")
 
 
# =============================================================================
# MAIN FUNCTION
# =============================================================================
 
def main():
    """
    Run the complete NHS A&E analysis pipeline in the correct order.
    """
 
    print("=" * 70)
    print("NHS A&E WAITING-TIME PERFORMANCE ANALYSIS")
    print("=" * 70)
 
    # STAGE 1
    raw_df = load_data()
 
    # STAGE 2
    explore_data(raw_df)
 
    # STAGE 3
    assess_data_quality(raw_df)
 
    # STAGE 4
    clean_df = clean_data(raw_df)
 
    # PHASE 1
    kpis = calculate_kpis(clean_df)
 
    # PHASE 2
    univariate_analysis(clean_df)
 
    # PHASE 3
    biv = bivariate_analysis(clean_df)
 
    # PHASE 4
    multiv = multivariate_analysis(clean_df)
 
    # FINAL MANAGEMENT SECTIONS
    final_insights(clean_df, kpis, biv, multiv)
    management_recommendations()
    project_limitations()
    conclusion(kpis, biv)
 
    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)
 
    return clean_df, kpis, biv, multiv
 
 
# =============================================================================
# RUN PROGRAM
# =============================================================================
 
if __name__ == "__main__":
    main()
 
 
# =============================================================================
# END OF NHS A&E WAITING-TIME PERFORMANCE ANALYSIS
# =============================================================================
